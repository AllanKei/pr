<?php
session_start();
if (!isset($_SESSION['aid'])){
  header('location:login.php');
}

include"db.php";
include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";
include"includes/modal.php";

?>
<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Blog Articles
            </h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Blog</li>
              </ol>
            </nav>
          </div>
          <?php

          if(isset($_SESSION['error'])){
              echo "
                      <div class='alert alert-danger text-center'>
                      <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                      <p>".$_SESSION['error']."</p> 
                      </div>
                  ";
              unset($_SESSION['error']);
          }

          if(isset($_SESSION['success'])){
              echo "
                      <div class='alert alert-success text-center'>
                      <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                      <p>".$_SESSION['success']."</p> 
                      </div>
                  ";
              unset($_SESSION['success']);
          }
          ?>
          <div class="card">
            <div class="card-body">
                <a href="addblog.php"><button class="btn btn-info card-title"><i class="fas fa-plus text-white"></i>Add</button></a>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Photo</th>
                            <th>Title</th>
                            <th>Content</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $n=0;
                      $n++;
                      $query = mysqli_query($con, "SELECT * FROM blog");
                      while($fetch = mysqli_fetch_array($query)){
                        

                      ?>
                        <tr>
                            <td><?php echo $n++?></td>
                            <td><img src="upload/<?php echo $fetch['photo']?>">
                              <a href="" data-toggle="modal"  data-target="#image<?php echo $fetch['blog_id']?>"  title="edit"><i class="fas fa-edit text-success"></i></a>
                          </td>
                            <td><?php echo $fetch['title']?></td>
                            <td><?php echo $fetch['content']?></td>
                            <td>
                              <a  href="editblog.php?id=<?php echo $fetch['blog_id']?>" title="edit"><i class="fas fa-edit text-success"></i></a>&nbsp&nbsp
                              <a href="" data-toggle="modal"  data-target="#delete<?php echo $fetch['blog_id']?>" title="delete"><i class="fas fa-trash text-danger"></i></a>
                            </td>
                        </tr>

                        <!-- Edit blog image -->
                        <div class="modal fade" id="image<?php echo $fetch['blog_id']?>">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit blog  image</h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                      <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                                          <div class="form-group">
                                              <label for="photo" class="col-sm-3 control-label">Photo</label>
                                              <div class="col-sm-5">
                                                  <input type="hidden" name="id" value="<?php echo $fetch['blog_id'] ?>">
                                                  <input type="file" id="image" name="image" value="<?php echo $fetch['photo'] ?>" >
                                              </div>
                                          </div>

                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                                      <button type="submit" class="btn btn-primary btn-flat" name="blogimage"><i class="fa fa-save"></i> Save</button>
                                      </form>
                                  </div>
                                </div>
                            </div>
                        </div>

                        <!-- Delete blog -->
                        <div class="modal fade" id="delete<?php echo $fetch['blog_id']?>">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete blog  title <?php echo $fetch['title']?></h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">Do you want to delete this blog ?</div>
                                    <div class="modal-footer">
                                        <form action="action.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $fetch ['blog_id']?>">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                            <button class="btn btn-danger" type="submit" name="delBlog">Delete</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <?php
                      }
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
<?php
include"includes/footer.php";