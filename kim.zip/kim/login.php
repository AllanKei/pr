<?php
session_start();
include"includes/header.php";
?>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth">
        <div class="row w-100">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left p-5">
              <h4 class="border-bottom">Admin Login</h4><br>
                <?php

                if(isset($_SESSION['error'])){
                    echo "
                            <div class='alert alert-danger text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                            <p>".$_SESSION['error']."</p> 
                            </div>
                        ";
                    unset($_SESSION['error']);
                }

                if(isset($_SESSION['success'])){
                    echo "
                            <div class='alert alert-success text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                            <p>".$_SESSION['success']."</p> 
                            </div>
                        ";
                    unset($_SESSION['success']);
                }
                ?>

                <form class="cmxform" id="signupForm" method="post" action="action.php">
                    <fieldset>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" class="form-control" name="email" type="email">
                      </div>
                      <div class="form-group">
                        <label for="password">Password</label>
                        <input id="password" class="form-control" name="password" type="password">
                      </div>

                      <div class="mt-3">
                        <button type="submit" name="login" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">Login </button>
                      </div>
                      
                    </fieldset>
                  </form>

            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
 <?php
 include"includes/footer.php";
 ?>
