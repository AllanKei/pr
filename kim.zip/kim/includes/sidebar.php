
<!-- Sidebar -->
<div class="container-fluid page-body-wrapper">  
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
        <div class="nav-link">
            <div class="profile-name">
            <p class="name">
                Welcome <?php echo $_SESSION['name']?>
            </p>
            <p class="designation">
                 Administrator
            </p>
            </div>
        </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <i class="fa fa-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="user.php">
                <i class="fa fa-user menu-icon"></i>
                <span class="menu-title">Users</span>
            </a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link" href="product.php">
                <i class="fa fa-puzzle-piece menu-icon"></i>
                <span class="menu-title">Products</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="order.php">
                <i class="fa fa-shopping-cart menu-icon"></i>
                <span class="menu-title">Orders</span>
            </a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link" href="blog.php">
                <i class="fa fa-file menu-icon"></i>
                <span class="menu-title">Blog articles</span>
            </a>
        </li>
        
    </ul>
    
    </nav>
    <!-- partial -->