<?php
session_start();
include"db.php";

$_SESSION['start']=1;
$visit=$_SESSION['start'];

$sql = "SELECT * FROM visit";
$run_query = mysqli_query($con,$sql);
$row = mysqli_fetch_array($run_query);
$count=$row['visit'];


$count1=$count + $visit;


$query_run="UPDATE visit SET `visit`= '$count1'";
$run_=mysqli_query($con,$query_run);
// $row_=mysqli_fetch_array($run_);

// $count2=$row_['visit'];

echo $count;


?>