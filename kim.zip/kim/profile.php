<?php
session_start();
if (!isset($_SESSION['aid'])){
  header('location:login.php');
}

include"db.php";
include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";
include"includes/modal.php";

$userid = $_SESSION['aid'];
$query = mysqli_query($con, "SELECT * FROM user WHERE user_id = $userid");
$fetch = mysqli_fetch_array($query);
$type=$fetch['type'];

?>
<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Profile
            </h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profile</li>
              </ol>
            </nav>
          </div>
          <?php

            if(isset($_SESSION['error'])){
                echo "
                        <div class='alert alert-danger text-center'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <p>".$_SESSION['error']."</p> 
                        </div>
                    ";
                unset($_SESSION['error']);
            }

            if(isset($_SESSION['success'])){
                echo "
                        <div class='alert alert-success text-center'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <p>".$_SESSION['success']."</p> 
                        </div>
                    ";
                unset($_SESSION['success']);
            }
            ?>
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-8">
                      <div class="border-bottom text-center pb-4">
                        <img src="images/user1.png" alt="profile" class="img-lg rounded-circle mb-3"/>
                        <h3><?php echo $fetch['names']?></h3>
                        <p>PR System administrator </p>
                        
                      </div>
                      <div class="mt-4 py-2 border-bottom">
                        <h5>Profile Details</h5>
                      </div>
                      <div class="profile-feed">
                        <form class="cmxform py-4" id="signup" method="post" action="action.php">
                        <fieldset>
                          <div class="form-group">
                            <label for="firstname">Full names</label>
                            <input type="hidden" name="id" value="<?php echo $userid?>">
                            <input id="name" class="form-control" name="name" type="text" value="<?php echo $fetch['names']?>">
                          </div>
                          <div class="form-group">
                            <label for="email">Email</label>
                            <input id="email" class="form-control" name="email" type="email" value="<?php echo $fetch['email']?>">
                          </div>
                          <div class="form-group">
                            <label for="contact">Contact</label>
                            <input id="contact" class="form-control" name="contact" type="number" value="<?php echo $fetch['contact']?>">
                          </div>
                          <div class="form-group">
                            <label for="address">Address</label>
                            <input id="address" class="form-control" name="address" type="text" value="<?php echo $fetch['address']?>">
                          </div>
                          
                          <input class="btn btn-primary" type="submit" name="editprof" value="Change profile details">
                        </fieldset>
                      </form>
                        
                        
                      </div>
                      
                    </div>
                    <div class="col-lg-4 pl-lg-5">
                      <div class="border-bottom py-4">
                          <h6 class="border-bottom pb-4"><strong>Change Password</strong></h6>
                          <form class="cmxform py-4" id="signupForm" method="post" action="action.php">
                            <fieldset>
                              <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="hidden" name="id" value="<?php echo $userid?>">
                                <input id="current_password" class="form-control" name="current_password" type="password">
                              </div>
                              <div class="form-group">
                                <label for="password">Password</label>
                                <input id="password" class="form-control" name="password" type="password">
                              </div>
                              <div class="form-group">
                                <label for="confirm_password">Confirm password</label>
                                <input id="confirm_password" class="form-control" name="confirm_password" type="password">
                              </div>
                              
                              <input class="btn btn-primary" type="submit" name="editpass" value="Change Password">
                            </fieldset>
                          </form>                                                              
                        </div>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->

<?php
include"includes/footer.php";
?>