<?php
session_start();
include 'db.php';

//admin login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE email = '$email'AND password = '$password' AND type='1'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["aid"] = $row["user_id"];
    $_SESSION["name"] = $row["names"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            echo 'login_success';
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}

//logout

if (isset($_POST['logout'])){
    unset($_SESSION['aid']);

    header('location:login.php');
}

//add user
if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $type = $_POST['type'];

    $date = date('Y-m-d');

    
    //existing email address in our database
    $sql = "SELECT user_id FROM user WHERE email = '$email' LIMIT 1";
    $check_query = mysqli_query($con, $sql);
    $count_email = mysqli_num_rows($check_query);
    
    if ($count_email > 0) {
        $_SESSION['error'] = 'Email already exists';
        header('location:user.php');

    } else {

        $sql = "INSERT INTO `user` 
    (`user_id`, `names`,`email`, 
    `password`,`address`,`contact`,`type`,`created_on`) 
    VALUES (NULL, '$name', '$email', 
    '$password','$address','$contact','$type','$date')";
        $run_query = mysqli_query($con, $sql);
        if ($run_query) {
            $_SESSION['success'] = 'User added successfully';
            header('location:user.php');

        }
        else{
            $_SESSION['error'] = 'User not added successfully';
            header('location:user.php');
        }
    }
    
}

//edit user
if (isset($_POST['edituser'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $type = $_POST['type'];


    
    $sql = "UPDATE user SET `names`= '$name',`email` = '$email',`type` = '$type',`address`='$address',`contact`='$contact' WHERE user_id = '$id' ";
    $run_query = mysqli_query($con, $sql);
    if ($run_query) {
        $_SESSION['success'] = 'User details updated successfully';
        header('location:user.php');
    } else {
        $_SESSION['error'] = 'User details not updated successfully';
        header('location:user.php');
    }

}

//delete user
if (isset($_POST['deluser'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM user WHERE user_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "User deleted successfully";
        header('location:user.php');
    }
    else{
        $_SESSION['error'] = 'User not deleted';
        header('location:user.php');
    }
}

//edit profile
if (isset($_POST['editprof'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];


    
    $sql = "UPDATE user SET `names`= '$name',`email` = '$email',`address`='$address',`contact`='$contact' WHERE user_id = '$id' ";
    $run_query = mysqli_query($con, $sql);
    if ($run_query) {
        $_SESSION['success'] = 'Profile details updated successfully';
        header('location:profile.php');
    } else {
        $_SESSION['error'] = 'Profile details not updated successfully';
        header('location:profile.php');
    }

}

//change profile password
if (isset($_POST['editpass'])) {
    $id = $_POST['id'];
    $pass = $_POST['current_password'];
    $password = $_POST['password'];

    //confirm if current password are matching
    $sql = "SELECT * FROM user WHERE user_id = '$id'";
    $check_query = mysqli_query($con, $sql);
    $count_pass = mysqli_fetch_array($check_query);
    $current_pass=$count_pass['password'];


    if($pass===$current_pass){

        $sql = "UPDATE user SET `password`= '$password' WHERE user_id = '$id' ";
        $run_query = mysqli_query($con, $sql);
        if ($run_query) {
            $_SESSION['success'] = 'Password updated successfully';
            header('location:profile.php');
        } else {
            $_SESSION['error'] = 'Password not updated successfully';
            header('location:profile.php');
        }

    }
    else{
        $_SESSION['error'] = 'Invalid current password';
        header('location:profile.php');
    }

    
    
}


//add product
if (isset($_POST['addProduct'])){
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity =$_POST['quantity'];

    // Get image name
    $image = $_FILES['image']['name'];

    // image file directory
    $target = "../upload/".basename($image);

    $sql = "INSERT INTO products (`product_id`,`product_name`,`price`,`photo`,`quantity`) VALUES(NULL,'$name','$price','$image','$quantity') ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $_SESSION['success'] = "Image uploaded successfully";
        header('location:product.php');
    }else {
        $_SESSION['error'] = "Failed to upload image";
        header('location:product.php');
    }
    if ($query){
        $_SESSION['success']='Product added successfully';
        header('location:product.php');
    }
    else{
        $_SESSION['error']='Product not added successfully';
        header('location:product.php');
    }
}

//edit product
if (isset($_POST['editProduct'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity =$_POST['quantity'];

    $sql = "UPDATE products SET `product_name` = '$name',`price` = '$price',`quantity`='$quantity' WHERE product_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Product updated successfully';
        header('location:product.php');
    }
    else{
        $_SESSION['error']='Product not updated';
        header('location:product.php');
    }
}
//edit productimage
if (isset($_POST['productimage'])){
    $id = $_POST['id'];
    // Get image name
    $image = $_FILES['image']['name'];
    // echo $image;
    // die();

    // image file directory
    $target = "../upload/".basename($image);

    $sql = "UPDATE products SET `photo` = '$image' WHERE product_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $_SESSION['success'] = "Image uploaded successfully";
        header('location:product.php');
    }else {
        $_SESSION['error'] = "Failed to upload image";
        header('location:product.php');
    }

}
//delete product
if (isset($_POST['delproduct'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM products WHERE product_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "Product deleted successfully";
        header('location:product.php');
    }
    else{
        $_SESSION['error'] = 'Product not deleted';
        header('location:product.php');
    }
}

//add blog
if (isset($_POST['addBlog'])){
    $title = $_POST['title'];
    $content = $_POST['content'];

    $date=date('Y-m-d');
    

    // Get image name
    $image = $_FILES['image']['name'];

    // image file directory
    $target = "upload/".basename($image);

    $sql = "INSERT INTO blog (`blog_id`,`title`,`content`,`date`,`photo`) 
    VALUES(NULL,'$title','$content','$date','$image') ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $_SESSION['success'] = "Image uploaded successfully";
        header('location:blog.php');
    }else {
        $_SESSION['error'] = "Failed to upload image";
        header('location:blog.php');
    }
    if ($query){
        $_SESSION['success']='Blog added successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog not added successfully';
        header('location:blog.php');
    }
}

//edit blog
if (isset($_POST['editBlog'])){
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    $sql = "UPDATE blog SET `title` = '$title',`content` = '$content' WHERE blog_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Blog updated successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog not updated';
        header('location:blog.php');
    }
}
//edit blogimage
if (isset($_POST['blogimage'])){
    $id = $_POST['id'];
    // Get image name
    $image = $_FILES['image']['name'];

    // image file directory
    $target = "upload/".basename($image);


    $sql = "UPDATE blog SET `photo` = '$image' WHERE blog_id = '$id' ";
    $query = mysqli_query($con,$sql);
    

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $_SESSION['success'] = "Image uploaded successfully";
        header('location:blog.php');
    }else {
        $_SESSION['error'] = "Failed to upload image";
        header('location:blog.php');
    }

    if ($query){
        $_SESSION['success']='Blog image updated successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog image not updated';
        header('location:blog.php');
    }

}

//delete blog
if (isset($_POST['delBlog'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM blog WHERE blog_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "Blog deleted successfully";
        header('location:blog.php');
    }
    else{
        $_SESSION['error'] = 'Blog not deleted';
        header('location:blog.php');
    }
}

//edit order
if (isset($_POST['editorder'])) {
    $id = $_POST['id'];
    $status=$_POST['status'];


    
    $sql = "UPDATE orders_info SET `status`= '$status' WHERE order_id = '$id' ";
    $run_query = mysqli_query($con, $sql);
    if ($run_query) {
        $_SESSION['success'] = 'Order status updated successfully';
        header('location:order.php');
    } else {
        $_SESSION['error'] = 'Order status not updated successfully';
        header('location:order.php');
    }

}