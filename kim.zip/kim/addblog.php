<?php
session_start();


include"db.php";
include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";
include"includes/modal.php";

?>


<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
                Add blog
            </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="blog.php">Blog</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add blog</li>
                </ol>
            </nav>
          </div>
          
          
          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Add blog</h4>
                  <form class="cmxform" id="signupForm" method="post" action="action.php" enctype="multipart/form-data">
                    <fieldset>
                      <div class="form-group">
                        <label for="firstname">Title</label>
                        <input id="title" class="form-control" name="title" type="text">
                      </div>
                      <div class="form-group">
                        <label for="photo">Blog Image</label>
                        <input type="file" name="image" class="dropify" />
                      </div>
                      <div class="form-group">
                        <label for="photo">Blog Content</label>
                        <textarea class="form-control" id="exampleTextarea1" name="content" rows="10"></textarea>
                      <br>
                      
                      
                      <input class="btn btn-primary" name="addBlog" type="submit" value="Submit">
                    </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
    
      </div>
      <!-- main-panel ends -->
</div>
</div>



<?php
include"includes/footer.php";
?>