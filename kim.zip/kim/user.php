<?php
session_start();
if (!isset($_SESSION['aid'])){
  header('location:login.php');
}

include"db.php";
include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";
include"includes/modal.php";

?>

<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Users
            </h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Users</li>
              </ol>
            </nav>
          </div>
          <?php

                if(isset($_SESSION['error'])){
                    echo "
                            <div class='alert alert-danger text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                            <p>".$_SESSION['error']."</p> 
                            </div>
                        ";
                    unset($_SESSION['error']);
                }

                if(isset($_SESSION['success'])){
                    echo "
                            <div class='alert alert-success text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                            <p>".$_SESSION['success']."</p> 
                            </div>
                        ";
                    unset($_SESSION['success']);
                }
                ?>
          <div class="card">
            <div class="card-body">
            <a href="adduser.php" class="btn btn-info card-title"><i class="fas fa-plus text-white"></i>Add</a>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>#</th>
                            <th>Names</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Joined on</th>
                            <th>Type</th>
                            <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $n=0;
                      $n++;
                      $query = mysqli_query($con, "SELECT * FROM user");
                      while($fetch = mysqli_fetch_array($query)){
                        $type=$fetch['type'];

                      ?>
                        <tr>
                            <td><?php echo $n++?></td>
                            <td><?php echo $fetch['names'] ?></td>
                            <td><?php echo $fetch['email'] ?></td>
                            <td><?php echo $fetch['contact'] ?></td>
                            <td><?php echo $fetch['address'] ?></td>
                            <td><?php echo $fetch['created_on'] ?></td>
                            <td>
                              <?php
                              if($type==1){
                                echo'<label class="badge badge-success">Admin</label>';
                              }
                              else{
                                echo'<label class="badge badge-info">User</label>';
                              }
                              ?>

                              
                            </td>
                            <td>
                              <a href="edituser.php?id=<?php echo $fetch['user_id']?>" title="edit"><i class="fas fa-edit text-success"></i></a>&nbsp&nbsp
                              <a href="" data-toggle="modal"  data-target="#delete<?php echo $fetch['user_id']?>" title="delete"><i class="fas fa-trash text-danger"></i></a>
                            </td>
                        </tr>

                        <!-- Delete user -->
                        <div class="modal fade" id="delete<?php echo $fetch['user_id']?>">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete user <?php echo $fetch['names']?></h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">Do you want to remove user <?php echo $fetch ['names']?>?</div>
                                    <div class="modal-footer">
                                        <form action="action.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $fetch ['user_id']?>">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                            <button class="btn btn-danger" type="submit" name="deluser">Delete</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <?php
                      }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
<?php
include"includes/footer.php";