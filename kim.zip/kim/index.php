<?php
session_start();
if (!isset($_SESSION['aid'])){
  header('location:login.php');
}

include"db.php";
include"includes/header.php";
include"includes/navbar.php";
include"includes/sidebar.php";
include"includes/modal.php";

?>

<!-- partial -->
<div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Dashboard
            </h3>
          </div>
          <div class="row grid-margin">
            <div class="col-12">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="d-flex flex-column flex-md-row align-items-center justify-content-between">
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fa fa-user mr-2"></i>
                          Users 
                        </p>
                        <?php
                        $query = "SELECT COUNT(*) AS count_item FROM user";
                        $query_run = mysqli_query($con,$query);
                        $row = mysqli_fetch_array($query_run);
                        $count = $row["count_item"];

                        ?>
                        <h2><?php echo $count?></h2>
                        <a href="user.php"><label class="badge badge-outline-success badge-pill">View</label></a>
                      </div>
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fas fa-hourglass-half mr-2"></i>
                          Blog Articles
                        </p>
                        <?php
                        $query = "SELECT COUNT(*) AS count_item FROM blog";
                        $query_run = mysqli_query($con,$query);
                        $row = mysqli_fetch_array($query_run);
                        $count = $row["count_item"];

                        ?>
                        <h2><?php echo $count?></h2>
                        <a href="blog.php"><label class="badge badge-outline-danger badge-pill">View</label></a>
                      </div>
                      <div class="statistics-item">
                        <p>
                          <i class="icon-sm fas fa-cloud-download-alt mr-2"></i>
                          Site visitors
                        </p>
                        <?php
                        $query = "SELECT * FROM visit";
                        $query_run = mysqli_query($con,$query);
                        $row = mysqli_fetch_array($query_run);
                        $count = $row["visit"];

                        ?>
                        <h2><?php echo $count?></h2>
                        <a href="product.php"><label class="badge badge-outline-success badge-pill">View</label></a>
                      </div>
                      <!-- <div class="statistics-item">
                        <p>
                          <i class="icon-sm fas fa-check-circle mr-2"></i>
                          Orders
                        </p>
                        <?php
                        // $query = "SELECT COUNT(*) AS count_item FROM orders_info";
                        // $query_run = mysqli_query($con,$query);
                        // $row = mysqli_fetch_array($query_run);
                        // $count = $row["count_item"];

                        ?>
                        <h2><?php //echo $count?></h2>
                        <a href="order.php"><label class="badge badge-outline-success badge-pill">View</label></a>
                      </div> -->
                      
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          
          <div class="row">
            <div class="col-md-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                  <h4 class="card-title">
                    <i class="fas fa-thumbtack"></i>
                    Todo
                  </h4>
                  <div class="add-items d-flex">
										<input type="text" class="form-control todo-list-input"  placeholder="What do you need to do today?">
										<button class="add btn btn-primary font-weight-bold todo-list-add-btn" id="add-task">Add</button>
									</div>
									<div class="list-wrapper">
										<ul class="d-flex flex-column-reverse todo-list">
											<li>
												<div class="form-check">
													<label class="form-check-label">
														<input class="checkbox" type="checkbox">
														Write Blogs
													</label>
												</div>
												<i class="remove fa fa-times-circle"></i>
											</li>
											
										</ul>
									</div>
                </div>
              
              </div>
            </div>
            <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">
                    <i class="fas fa-calendar-alt"></i>
                    Calendar
                  </h4>
                  <div id="inline-datepicker-example" class="datepicker"></div>
                </div>
              </div>
            </div>
          </div>
          
          
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021. All rights reserved.</span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>


</html>
